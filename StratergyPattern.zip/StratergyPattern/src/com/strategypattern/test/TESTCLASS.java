package com.strategypattern.test;

public class TESTCLASS {

}
