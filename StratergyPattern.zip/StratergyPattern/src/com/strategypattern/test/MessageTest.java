package com.strategypattern.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

//import com.strategypattern.beans.IMessageProducer;
import com.strategypattern.beans.MessageWriter;
///import com.strategypattern.beans.TextMessageProducer;

class AppFactory {
	public static Object createObject(String messageWriter,
			String iMessageProducer) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, IOException {
		Object obj = null;
		String className = null;
		Properties props = null;
		FileInputStream fis = null;
		fis = new FileInputStream(
				"D:\\StratergyPattern\\src\\application.properties");
		props = new Properties();
		props.load(fis);
		if (props.size() < 0) {
			throw new ClassNotFoundException("Unable to find file");
		} else if (props.containsKey(messageWriter) == false) {
			throw new ClassNotFoundException("Unable to find key"
					+ messageWriter);
		}

		className = props.getProperty(messageWriter);				
		obj = Class.forName(className).newInstance();
		return obj;

	}

}

public class MessageTest {
	public static void main(String[] args) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, IOException {

		Object o = AppFactory.createObject("messageWriter", "iMessageProducer");
		MessageWriter writer = (MessageWriter) o;
		writer.writeMessage("Hello Spring");
		// writer.setmessageProducer(messageproducer)
		// MessageWriter writer=new MessageWriter();

		
		  /*MessageWriter writer = new MessageWriter(); 
		  IMessageProducer messageProducer = new TextMessageProducer();
		  writer.setmessageProducer(messageProducer);
		  writer.writeMessage("welcome to spring");*/
		 

	}
}