package com.strategypattern.beans;

public class HtmlMessageProducer implements IMessageProducer{
	public String convertMessage(String message){
		return "<HTML><HEAD></HEAD><BODY>"+message+"</BODY></HTML>";
	}

}
