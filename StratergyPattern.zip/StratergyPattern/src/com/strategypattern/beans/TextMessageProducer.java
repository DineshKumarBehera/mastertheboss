package com.strategypattern.beans;

public class TextMessageProducer implements IMessageProducer{
	public String convertMessage(String message){
		return "hello" +message+ "!";
	}

}
