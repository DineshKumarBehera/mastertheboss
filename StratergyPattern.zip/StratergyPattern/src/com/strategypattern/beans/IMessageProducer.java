package com.strategypattern.beans;

public interface IMessageProducer {
	public String convertMessage(String message);


}
