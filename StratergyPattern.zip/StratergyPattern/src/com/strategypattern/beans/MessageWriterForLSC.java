package com.strategypattern.beans;

public class MessageWriterForLSC {
	IMessageProducer messageProducer;
	

}
