package com.strategypattern.beans;

public class MessageProducerFactory {
	public static IMessageProducer createMessageProducer(String type){
		if(type.equals("html")){
			return new HtmlMessageProducer();
		}
		else if(type.equals("text")){
			return new TextMessageProducer();
		}
		return null;
	}

}
