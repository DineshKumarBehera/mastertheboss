package com.strategypattern.beans;


public class MessageWriter{
	private IMessageProducer messageproducer;
	public void writeMessage(String message){
		messageproducer=MessageProducerFactory.createMessageProducer("html");
		String formateddata=messageproducer.convertMessage("Welcome");
		System.out.println(formateddata);	
		System.out.println(message);
	}
	public void setmessageProducer(IMessageProducer messageproducer){
		this.messageproducer=messageproducer;
	}
	public IMessageProducer getMessageproducer() {
		return messageproducer;
	}	

}
